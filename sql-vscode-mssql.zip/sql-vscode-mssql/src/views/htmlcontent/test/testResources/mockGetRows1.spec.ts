import { ResultSetSubset } from './../../src/js/interfaces';

const rows: ResultSetSubset = {
    rowCount: 50,
    rows: [
        [{displayValue: 'data', isNull: false}]
    ]
};

export default rows;
