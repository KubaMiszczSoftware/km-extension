/// <reference path="jquery/jquery.d.ts" />
