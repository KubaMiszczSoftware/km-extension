# Installation
> `npm install --save @types/jasmine`

# Summary
This package contains type definitions for Jasmine 2.5 (http://jasmine.github.io/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/jasmine

Additional Details
 * Last updated: Tue, 01 Nov 2016 12:57:25 GMT
 * File structure: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: afterAll, afterEach, beforeAll, beforeEach, describe, expect, fail, fdescribe, fit, it, jasmine, pending, runs, spyOn, waits, waitsFor, xdescribe, xit

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov/>, Theodore Brown <https://github.com/theodorejb>, David Pärsson <https://github.com/davidparsson/>.
