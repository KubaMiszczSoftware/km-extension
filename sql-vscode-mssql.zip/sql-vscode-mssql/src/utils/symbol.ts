'use strict';

export const star = '✰';
