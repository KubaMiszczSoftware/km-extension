'use strict';

export default require('error-ex')('ValidationException');
