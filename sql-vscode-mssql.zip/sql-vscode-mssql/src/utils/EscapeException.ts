'use strict';

export default require('error-ex')('EscapeException');
