- MSSQL Extension Version:
- VSCode Version:
- OS Version:

Steps to Reproduce:

1.
2.
