/// <reference path="globals/istanbul/index.d.ts" />
/// <reference path="globals/underscore/index.d.ts" />
