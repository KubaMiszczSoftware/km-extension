declare module "getmac" {
    export function getMac(callback: (err: Error, result: string) => void): void;
}
