-- Select rows from a Table or View 'TableOrViewName' in schema 'SchemaName'
GO
SELECT * FROM DB2_ALIAS_NICK.A
GO